const API_BASE = "http://localhost:3000";

let products = [];

function renderProducts(items) {
    const table = document.getElementById("searchResultsTable");

    if (!table) {
        return;
    }

    table.innerHTML = "";

    if (items.length === 0) {
        table.innerHTML = "<tr><td colspan='6'>No products found.</td></tr>";
        return;
    }

    items.forEach(function (product) {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${product.product_id}</td>
            <td>${product.title}</td>
            <td>${product.category}</td>
            <td>${product.type}</td>
            <td>$${Number(product.price).toFixed(2)}</td>
            <td><button type="button">Add</button></td>
        `;

        row.querySelector("button").addEventListener("click", function () {
            addToCart(product.product_id);
        });

        table.appendChild(row);
    });
}

function renderCart(items) {
    const table = document.getElementById("cartTable");

    if (!table) {
        return;
    }

    table.innerHTML = "";

    if (items.length === 0) {
        table.innerHTML = "<tr><td colspan='6'>Cart is empty.</td></tr>";
        return;
    }

    items.forEach(function (item) {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.product_id}</td>
            <td>${item.description}</td>
            <td>${item.category}</td>
            <td>${item.unit}</td>
            <td>$${Number(item.price).toFixed(2)}</td>
            <td><button type="button">Remove</button></td>
        `;

        row.querySelector("button").addEventListener("click", function () {
            removeFromCart(item.cart_id);
        });

        table.appendChild(row);
    });
}

async function loadProducts() {
    const response = await fetch(API_BASE + "/products");
    products = await response.json();
    renderProducts(products);
}

async function loadCart() {
    const response = await fetch(API_BASE + "/cart");
    const items = await response.json();
    renderCart(items);
}

function filterProducts() {
    const value = document.getElementById("searchInput").value.trim().toLowerCase();

    if (!value) {
        renderProducts(products);
        return;
    }

    const filtered = products.filter(function (product) {
        return String(product.product_id).includes(value) ||
            String(product.title || "").toLowerCase().includes(value) ||
            String(product.category || "").toLowerCase().includes(value) ||
            String(product.type || "").toLowerCase().includes(value);
    });

    renderProducts(filtered);
}

async function addToCart(productId) {
    const product = products.find(function (item) {
        return Number(item.product_id) === Number(productId);
    });

    if (!product) {
        return;
    }

    await fetch(API_BASE + "/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            product_id: product.product_id,
            description: product.title,
            category: product.category,
            unit: product.type,
            price: product.price,
            member_id: null
        })
    });

    await loadCart();
}

async function removeFromCart(cartId) {
    await fetch(API_BASE + "/cart/" + cartId, {
        method: "DELETE"
    });

    await loadCart();
}

document.addEventListener("DOMContentLoaded", function () {
    const searchButton = document.getElementById("searchBtn");
    const searchInput = document.getElementById("searchInput");
    const sendDataBtn = document.getElementById("sendDataBtn");

    if (searchButton) {
        searchButton.addEventListener("click", filterProducts);
    }

    if (searchInput) {
        searchInput.addEventListener("input", filterProducts);
        searchInput.addEventListener("keyup", function (event) {
            if (event.key === "Enter") {
                filterProducts();
            }
        });
    }

    if (sendDataBtn) {
        sendDataBtn.addEventListener("click", loadCart);
    }

    loadProducts();
    loadCart();
});
