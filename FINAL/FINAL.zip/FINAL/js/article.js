const API_BASE = "http://localhost:3000";

async function loadArticles() {
    const container = document.getElementById("articlesList");

    if (!container) {
        return;
    }

    const response = await fetch(API_BASE + "/articles");
    const articles = await response.json();

    if (articles.length === 0) {
        container.innerHTML = "<p>No articles have been submitted yet.</p>";
        return;
    }

    container.innerHTML = articles.map(function (article) {
        return `
            <article class="card mb-3">
                <div class="card-body">
                    <h3 class="h5 mb-2">${article.title}</h3>
                    <p class="mb-1"><strong>Author ID:</strong> ${article.author_id}</p>
                    <p class="mb-1"><strong>Category:</strong> ${article.category}</p>
                    <p class="mb-1"><strong>Status:</strong> ${article.review_status}</p>
                    <p class="mb-1"><strong>Publication Date:</strong> ${article.pub_date}</p>
                    <p class="mb-0"><strong>Editorial Notes:</strong> ${article.editorial_notes || "None"}</p>
                </div>
            </article>
        `;
    }).join("");
}

async function submitArticle(event) {
    event.preventDefault();

    const title = document.getElementById("title").value.trim();
    const author = document.getElementById("author").value.trim();
    const pubDate = document.getElementById("pubDate").value;
    const reviewStatus = document.getElementById("reviewStatus").value;
    const category = document.getElementById("category").value;
    const notes = document.getElementById("notes").value.trim();
    const errorMsg = document.getElementById("errorMsg");

    errorMsg.textContent = "";

    if (!title || !author || !pubDate || !reviewStatus || !category) {
        errorMsg.textContent = "Please fill in all required fields.";
        return;
    }

    const response = await fetch(API_BASE + "/articles", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            author_id: author,
            title: title,
            category: category,
            pub_date: pubDate,
            review_status: reviewStatus,
            editorial_notes: notes || null
        })
    });

    if (!response.ok) {
        errorMsg.textContent = "Error submitting article.";
        return;
    }

    document.getElementById("finalForm").reset();
    await loadArticles();
}

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("finalForm");

    if (form) {
        form.addEventListener("submit", submitArticle);
    }

    loadArticles();
});
