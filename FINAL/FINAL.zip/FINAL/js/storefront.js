const API_BASE = "http://localhost:3000";

let products = [];

async function loadProducts() {
    const response = await fetch(API_BASE + "/products");
    products = await response.json();

    const container = document.getElementById("productList");

    if (!container) {
        return;
    }

    if (products.length === 0) {
        container.innerHTML = "<p>No products available.</p>";
        return;
    }

    container.innerHTML = products.map(function (product) {
        return `
            <article class="product-card">
                <div class="product-image-wrap">
                    <img src="${product.image_url || 'https://via.placeholder.com/420x320?text=No+Image'}" alt="${product.title || 'Product'}">
                </div>
                <div class="product-copy">
                    <h3>${product.title}</h3>
                    <p class="product-price">$${Number(product.price).toFixed(2)}</p>
                    <p><strong>Category:</strong> ${product.category}</p>
                    <p><strong>Type:</strong> ${product.type}</p>
                    <button type="button" onclick="addToCart(${product.product_id})">Add to Cart</button>
                </div>
            </article>
        `;
    }).join("");
}

async function addToCart(productId) {
    const product = products.find(function (item) {
        return Number(item.product_id) === Number(productId);
    });

    if (!product) {
        return;
    }

    await fetch(API_BASE + "/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            product_id: product.product_id,
            description: product.title,
            category: product.category,
            unit: product.type,
            price: product.price,
            member_id: null
        })
    });

    alert("Added to cart");
}

document.addEventListener("DOMContentLoaded", loadProducts);
