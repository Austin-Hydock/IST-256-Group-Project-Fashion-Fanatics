const API_BASE = "http://localhost:3000";

let products = [];

function getFormData() {
    return {
        product_id: Number(document.getElementById("productID").value.trim()),
        title: document.getElementById("title").value.trim(),
        type: document.getElementById("type").value.trim(),
        category: document.getElementById("category").value.trim(),
        price: Number(document.getElementById("price").value.trim()),
        image_url: document.getElementById("imageURL").value.trim() || null,
        extra_info: document.getElementById("extra").value.trim() || null
    };
}

function validateForm(product) {
    if (!product.product_id || !product.title || !product.type || !product.category || !product.price) {
        alert("Please fill in all required fields.");
        return false;
    }

    if (Number.isNaN(product.price) || product.price <= 0) {
        alert("Price must be a positive number.");
        return false;
    }

    return true;
}

function renderTable(dataArray) {
    const tbody = document.getElementById("productTableBody");

    if (!tbody) {
        return;
    }

    tbody.innerHTML = "";

    if (dataArray.length === 0) {
        tbody.innerHTML = "<tr><td colspan='8'>No products found.</td></tr>";
        return;
    }

    dataArray.forEach(function (product) {
        const row = document.createElement("tr");
        const imageHtml = product.image_url
            ? `<img src="${product.image_url}" alt="${product.title || "Product"}" width="50">`
            : "";

        row.innerHTML =
            "<td>" + imageHtml + "</td>" +
            "<td>" + product.product_id + "</td>" +
            "<td>" + product.title + "</td>" +
            "<td>" + product.type + "</td>" +
            "<td>" + product.category + "</td>" +
            "<td>$" + Number(product.price).toFixed(2) + "</td>" +
            "<td>" + (product.extra_info || "") + "</td>" +
            "<td>" +
                "<button type=\"button\" data-action=\"edit\">Edit</button> " +
                "<button type=\"button\" data-action=\"delete\">Delete</button>" +
            "</td>";

        row.querySelector('[data-action="edit"]').addEventListener("click", function () {
            document.getElementById("productID").value = product.product_id;
            document.getElementById("title").value = product.title || "";
            document.getElementById("type").value = product.type || "";
            document.getElementById("category").value = product.category || "";
            document.getElementById("price").value = product.price || "";
            document.getElementById("imageURL").value = product.image_url || "";
            document.getElementById("extra").value = product.extra_info || "";
        });

        row.querySelector('[data-action="delete"]').addEventListener("click", function () {
            deleteProduct(product.product_id);
        });

        tbody.appendChild(row);
    });
}

async function loadProducts() {
    const response = await fetch(API_BASE + "/products");
    products = await response.json();
    renderTable(products);
}

function filterProducts() {
    const searchValue = document.getElementById("searchInput").value.trim().toLowerCase();

    if (!searchValue) {
        renderTable(products);
        return;
    }

    const filtered = products.filter(function (product) {
        return String(product.product_id).toLowerCase().includes(searchValue) ||
            String(product.title || "").toLowerCase().includes(searchValue) ||
            String(product.category || "").toLowerCase().includes(searchValue) ||
            String(product.type || "").toLowerCase().includes(searchValue);
    });

    renderTable(filtered);
}

async function saveProduct(event) {
    event.preventDefault();

    const product = getFormData();

    if (!validateForm(product)) {
        return;
    }

    const existing = products.find(function (item) {
        return Number(item.product_id) === product.product_id;
    });

    const requestOptions = {
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(product)
    };

    if (existing) {
        await fetch(API_BASE + "/products/" + product.product_id, Object.assign({ method: "PUT" }, requestOptions));
    } else {
        await fetch(API_BASE + "/products", Object.assign({ method: "POST" }, requestOptions));
    }

    document.getElementById("productForm").reset();
    await loadProducts();
}

async function deleteProduct(productId) {
    if (!confirm("Delete this product?")) {
        return;
    }

    await fetch(API_BASE + "/products/" + productId, {
        method: "DELETE"
    });

    await loadProducts();
}

document.addEventListener("DOMContentLoaded", function () {
    const productForm = document.getElementById("productForm");
    const searchButton = document.getElementById("searchButton");
    const searchInput = document.getElementById("searchInput");

    if (productForm) {
        productForm.addEventListener("submit", saveProduct);
    }

    if (searchButton) {
        searchButton.addEventListener("click", filterProducts);
    }

    if (searchInput) {
        searchInput.addEventListener("input", filterProducts);
    }

    loadProducts();
});
